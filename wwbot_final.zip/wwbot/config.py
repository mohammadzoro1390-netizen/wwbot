# ─── تنظیمات ربات ───────────────────────────────────────
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
OWNER_ID  = "YOUR_USER_ID_HERE"
DB_PATH   = "ww_game.db"
API_URL   = "https://botapi.rubika.ir"

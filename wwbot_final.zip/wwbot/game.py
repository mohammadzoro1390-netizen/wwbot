import sqlite3
import json
from datetime import datetime, date
from database import get_conn

# ═══════════════════════════════════════════════════════
#  ادمین
# ═══════════════════════════════════════════════════════

def is_admin(uid):
    conn = get_conn()
    r = conn.execute("SELECT id FROM admins WHERE user_id=?", (str(uid),)).fetchone()
    conn.close()
    return r is not None

def is_owner(uid):
    conn = get_conn()
    r = conn.execute("SELECT id FROM admins WHERE user_id=? AND is_owner=1", (str(uid),)).fetchone()
    conn.close()
    return r is not None

def add_admin(uid, name, by):
    conn = get_conn()
    try:
        conn.execute("INSERT INTO admins (user_id,name) VALUES (?,?)", (str(uid), name))
        conn.commit()
        return f"✅ ادمین «{name}» اضافه شد."
    except:
        return "❌ این کاربر قبلاً ادمینه."
    finally:
        conn.close()

def del_admin(uid, by):
    conn = get_conn()
    r = conn.execute("SELECT * FROM admins WHERE user_id=?", (str(uid),)).fetchone()
    if not r: conn.close(); return "❌ ادمین پیدا نشد."
    if r["is_owner"]: conn.close(); return "❌ اونر رو نمیشه حذف کرد."
    conn.execute("DELETE FROM admins WHERE user_id=?", (str(uid),))
    conn.commit(); conn.close()
    return "✅ ادمین حذف شد."

def list_admins():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM admins ORDER BY is_owner DESC").fetchall()
    conn.close()
    if not rows: return "❌ ادمینی نیست."
    t = "👮 *ادمین‌ها:*\n\n"
    for a in rows:
        t += f"{'👑' if a['is_owner'] else '🛡'} {a['name']} | `{a['user_id']}`\n"
    return t

# ═══════════════════════════════════════════════════════
#  کشورها
# ═══════════════════════════════════════════════════════

def add_country(name, flag, continent, by):
    conn = get_conn()
    try:
        conn.execute("INSERT INTO countries (name,flag,continent) VALUES (?,?,?)", (name, flag, continent))
        conn.commit()
        return f"✅ کشور {flag} {name} اضافه شد."
    except:
        return "❌ این کشور قبلاً وجود داره."
    finally:
        conn.close()

def del_country(cid, by):
    conn = get_conn()
    r = conn.execute("SELECT * FROM countries WHERE id=?", (cid,)).fetchone()
    if not r: conn.close(); return "❌ کشور پیدا نشد."
    conn.execute("DELETE FROM countries WHERE id=?", (cid,))
    conn.execute("UPDATE players SET country_id=NULL WHERE country_id=?", (cid,))
    conn.commit(); conn.close()
    return f"✅ کشور «{r['name']}» حذف شد."

def edit_country(cid, field, value, by):
    ok = {"name","flag","continent","money","oil","satisfaction","max_players"}
    if field not in ok:
        return f"❌ فیلد نامعتبر.\nفیلدها: {', '.join(ok)}"
    conn = get_conn()
    conn.execute(f"UPDATE countries SET {field}=? WHERE id=?", (value, cid))
    conn.commit(); conn.close()
    return f"✅ {field} = {value}"

def get_countries_list():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM countries WHERE is_active=1 ORDER BY continent,name").fetchall()
    conn.close()
    if not rows: return "❌ هنوز کشوری تعریف نشده."
    t = "🌍 *کشورهای موجود:*\n\n"
    last_cont = None
    for c in rows:
        if c["continent"] != last_cont:
            t += f"\n🗺 *{c['continent']}*\n"
            last_cont = c["continent"]
        full = c["current_players"] >= c["max_players"]
        status = "🔴" if full else "🟢"
        t += f"{status} {c['flag']} [{c['id']}] *{c['name']}* ({c['current_players']}/{c['max_players']})\n"
    t += "\nبرای انتخاب: /country [ID]"
    return t

def get_country(cid):
    conn = get_conn()
    r = conn.execute("SELECT * FROM countries WHERE id=?", (cid,)).fetchone()
    conn.close()
    return dict(r) if r else None

# ═══════════════════════════════════════════════════════
#  بازیکن
# ═══════════════════════════════════════════════════════

def get_or_create_player(uid, username=""):
    conn = get_conn()
    r = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not r:
        conn.execute("INSERT INTO players (user_id,username) VALUES (?,?)", (str(uid), username))
        conn.commit()
        r = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    conn.close()
    return dict(r)

def select_country(uid, cid, username=""):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if p and p["country_id"]:
        conn.close(); return "❌ قبلاً کشور انتخاب کردی.\nبرای تغییر با ادمین تماس بگیر."
    c = conn.execute("SELECT * FROM countries WHERE id=? AND is_active=1", (cid,)).fetchone()
    if not c: conn.close(); return "❌ کشور پیدا نشد."
    if c["current_players"] >= c["max_players"]: conn.close(); return f"❌ کشور «{c['name']}» پر شده."
    if p:
        conn.execute("UPDATE players SET country_id=?,username=? WHERE user_id=?", (cid, username, str(uid)))
    else:
        conn.execute("INSERT INTO players (user_id,username,country_id) VALUES (?,?,?)", (str(uid), username, cid))
    new_count = c["current_players"] + 1
    conn.execute("UPDATE countries SET current_players=? WHERE id=?", (new_count, cid))
    conn.commit()
    is_full = new_count >= c["max_players"]
    conn.close()
    return {"ok": True, "msg": f"✅ کشور {c['flag']} *{c['name']}* رو انتخاب کردی!\nموفق باشی 🌍", "is_full": is_full, "country_name": c["name"]}

def get_player_country(uid):
    conn = get_conn()
    r = conn.execute("""
        SELECT p.*, c.name as cname, c.flag, c.money, c.oil, c.satisfaction,
               c.army as carmy, c.id as cid
        FROM players p
        LEFT JOIN countries c ON p.country_id = c.id
        WHERE p.user_id=?""", (str(uid),)).fetchone()
    conn.close()
    return dict(r) if r else None

# ═══════════════════════════════════════════════════════
#  پروفایل
# ═══════════════════════════════════════════════════════

def cmd_profile(uid):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close()
        return "❌ هنوز کشور انتخاب نکردی!\n\n/country - انتخاب کشور"
    c = conn.execute("SELECT * FROM countries WHERE id=?", (p["country_id"],)).fetchone()

    # ارتش
    army_rows = conn.execute("""
        SELECT at.emoji, at.name, a.amount FROM army a
        JOIN army_types at ON a.army_type_id=at.id
        WHERE a.country_id=? AND a.amount>0""", (c["id"],)).fetchall()

    # ساختمان‌ها
    build_rows = conn.execute("""
        SELECT bt.emoji, bt.name, b.amount FROM buildings b
        JOIN building_types bt ON b.building_type_id=bt.id
        WHERE b.country_id=? AND b.amount>0""", (c["id"],)).fetchall()

    conn.close()

    t = f"{c['flag']} *{c['name']}*\n"
    t += f"━━━━━━━━━━━━━━━\n"
    t += f"💰 پول: {c['money']:,}\n"
    t += f"🛢 نفت: {c['oil']:,}\n"
    t += f"😊 رضایت: {c['satisfaction']}%\n"
    t += f"👥 بازیکنان: {c['current_players']}/{c['max_players']}\n"
    if army_rows:
        t += f"\n⚔️ *ارتش:*\n"
        for a in army_rows:
            t += f"  {a['emoji']} {a['name']}: {a['amount']:,}\n"
    if build_rows:
        t += f"\n🏛 *ساختمان‌ها:*\n"
        for b in build_rows:
            t += f"  {b['emoji']} {b['name']}: {b['amount']}\n"
    return t

# ═══════════════════════════════════════════════════════
#  اقتصاد
# ═══════════════════════════════════════════════════════

def cmd_economy(uid):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close(); return "❌ اول کشور انتخاب کن: /country"
    c = conn.execute("SELECT * FROM countries WHERE id=?", (p["country_id"],)).fetchone()
    cfg = conn.execute("SELECT * FROM daily_config ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    t = f"💰 *اقتصاد {c['flag']} {c['name']}*\n"
    t += f"━━━━━━━━━━━━━━━\n"
    t += f"💰 موجودی: {c['money']:,}\n"
    t += f"🛢 نفت: {c['oil']:,}\n"
    t += f"😊 رضایت: {c['satisfaction']}%\n\n"
    t += f"📊 *درآمد روزانه:*\n"
    t += f"  💰 +{cfg['money_reward']:,}\n"
    t += f"  🛢 +{cfg['oil_reward']:,}\n"
    t += f"  😊 +{cfg['satisfaction_reward']}%\n\n"
    t += f"برای دریافت پاداش امروز: /daily"
    return t

# ═══════════════════════════════════════════════════════
#  ارتش
# ═══════════════════════════════════════════════════════

def cmd_army(uid):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close(); return "❌ اول کشور انتخاب کن: /country"
    c = conn.execute("SELECT * FROM countries WHERE id=?", (p["country_id"],)).fetchone()
    types = conn.execute("SELECT * FROM army_types ORDER BY price").fetchall()
    if not types:
        conn.close(); return "❌ هنوز نوع ارتشی تعریف نشده.\n(ادمین باید تعریف کنه)"
    t = f"⚔️ *ارتش {c['flag']} {c['name']}*\n"
    t += f"💰 موجودی: {c['money']:,}\n"
    t += f"━━━━━━━━━━━━━━━\n"
    for at in types:
        owned = conn.execute("SELECT amount FROM army WHERE country_id=? AND army_type_id=?",
                             (c["id"], at["id"])).fetchone()
        amount = owned["amount"] if owned else 0
        t += f"\n{at['emoji']} *{at['name']}*\n"
        t += f"   💰 قیمت: {at['price']:,} | دارید: {amount:,}\n"
        t += f"   ⚔️ حمله: {at['attack']} | 🛡 دفاع: {at['defense']}\n"
        t += f"   /buy_army {at['id']} [تعداد]\n"
    conn.close()
    return t

def buy_army(uid, type_id, amount):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close(); return "❌ اول کشور انتخاب کن."
    at = conn.execute("SELECT * FROM army_types WHERE id=?", (type_id,)).fetchone()
    if not at: conn.close(); return "❌ نوع ارتش پیدا نشد."
    c = conn.execute("SELECT * FROM countries WHERE id=?", (p["country_id"],)).fetchone()
    total_cost = at["price"] * amount
    if c["money"] < total_cost:
        conn.close(); return f"❌ پول کافی نیست!\nنیاز: {total_cost:,} | موجودی: {c['money']:,}"
    conn.execute("UPDATE countries SET money=money-? WHERE id=?", (total_cost, c["id"]))
    existing = conn.execute("SELECT id FROM army WHERE country_id=? AND army_type_id=?",
                            (c["id"], type_id)).fetchone()
    if existing:
        conn.execute("UPDATE army SET amount=amount+? WHERE country_id=? AND army_type_id=?",
                     (amount, c["id"], type_id))
    else:
        conn.execute("INSERT INTO army (country_id,army_type_id,amount) VALUES (?,?,?)",
                     (c["id"], type_id, amount))
    conn.commit(); conn.close()
    return f"✅ {amount:,} عدد {at['emoji']} {at['name']} خریدی!\n💰 هزینه: {total_cost:,}"

# ═══════════════════════════════════════════════════════
#  ساختمان‌ها
# ═══════════════════════════════════════════════════════

def cmd_buildings(uid):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close(); return "❌ اول کشور انتخاب کن: /country"
    c = conn.execute("SELECT * FROM countries WHERE id=?", (p["country_id"],)).fetchone()
    types = conn.execute("SELECT * FROM building_types ORDER BY price").fetchall()
    if not types:
        conn.close(); return "❌ هنوز ساختمانی تعریف نشده.\n(ادمین باید تعریف کنه)"
    t = f"🏛 *ساختمان‌های {c['flag']} {c['name']}*\n"
    t += f"💰 موجودی: {c['money']:,}\n"
    t += f"━━━━━━━━━━━━━━━\n"
    for bt in types:
        owned = conn.execute("SELECT amount FROM buildings WHERE country_id=? AND building_type_id=?",
                             (c["id"], bt["id"])).fetchone()
        amount = owned["amount"] if owned else 0
        t += f"\n{bt['emoji']} *{bt['name']}*\n"
        t += f"   💰 قیمت: {bt['price']:,} | دارید: {amount}\n"
        t += f"   📈 اثر: +{bt['effect_value']} {bt['effect_type']}\n"
        if bt["description"]: t += f"   📝 {bt['description']}\n"
        t += f"   /buy_building {bt['id']} [تعداد]\n"
    conn.close()
    return t

def buy_building(uid, type_id, amount):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close(); return "❌ اول کشور انتخاب کن."
    bt = conn.execute("SELECT * FROM building_types WHERE id=?", (type_id,)).fetchone()
    if not bt: conn.close(); return "❌ ساختمان پیدا نشد."
    c = conn.execute("SELECT * FROM countries WHERE id=?", (p["country_id"],)).fetchone()
    total_cost = bt["price"] * amount
    if c["money"] < total_cost:
        conn.close(); return f"❌ پول کافی نیست!\nنیاز: {total_cost:,} | موجودی: {c['money']:,}"
    conn.execute("UPDATE countries SET money=money-? WHERE id=?", (total_cost, c["id"]))
    existing = conn.execute("SELECT id FROM buildings WHERE country_id=? AND building_type_id=?",
                            (c["id"], type_id)).fetchone()
    if existing:
        conn.execute("UPDATE buildings SET amount=amount+? WHERE country_id=? AND building_type_id=?",
                     (amount, c["id"], type_id))
    else:
        conn.execute("INSERT INTO buildings (country_id,building_type_id,amount) VALUES (?,?,?)",
                     (c["id"], type_id, amount))
    conn.commit(); conn.close()
    return f"✅ {amount} عدد {bt['emoji']} {bt['name']} ساختی!\n💰 هزینه: {total_cost:,}"

# ═══════════════════════════════════════════════════════
#  فروشگاه قاره‌ها
# ═══════════════════════════════════════════════════════

def cmd_shop(uid):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close(); return "❌ اول کشور انتخاب کن: /country"
    c = conn.execute("SELECT * FROM countries WHERE id=?", (p["country_id"],)).fetchone()
    items = conn.execute("SELECT * FROM shop_items WHERE continent=? OR continent='همه' ORDER BY price",
                         (c["continent"],)).fetchall()
    if not items:
        conn.close(); return "❌ آیتمی در فروشگاه نیست.\n(ادمین باید اضافه کنه)"
    t = f"🛍 *فروشگاه قاره {c['continent']}*\n"
    t += f"💰 موجودی: {c['money']:,}\n"
    t += f"━━━━━━━━━━━━━━━\n"
    for item in items:
        t += f"\n{item['emoji']} *{item['name']}*\n"
        t += f"   💰 قیمت: {item['price']:,}\n"
        t += f"   📈 +{item['effect_value']} {item['effect_type']}\n"
        if item["description"]: t += f"   📝 {item['description']}\n"
        t += f"   /buy_item {item['id']}\n"
    conn.close()
    return t

def buy_item(uid, item_id):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close(); return "❌ اول کشور انتخاب کن."
    item = conn.execute("SELECT * FROM shop_items WHERE id=?", (item_id,)).fetchone()
    if not item: conn.close(); return "❌ آیتم پیدا نشد."
    c = conn.execute("SELECT * FROM countries WHERE id=?", (p["country_id"],)).fetchone()
    if item["continent"] != "همه" and item["continent"] != c["continent"]:
        conn.close(); return f"❌ این آیتم فقط برای قاره {item['continent']} هست."
    if c["money"] < item["price"]:
        conn.close(); return f"❌ پول کافی نیست!\nنیاز: {item['price']:,} | موجودی: {c['money']:,}"
    conn.execute("UPDATE countries SET money=money-? WHERE id=?", (item["price"], c["id"]))
    ef = item["effect_type"]
    ev = item["effect_value"]
    if ef in ("money","oil","satisfaction"):
        conn.execute(f"UPDATE countries SET {ef}={ef}+? WHERE id=?", (ev, c["id"]))
    conn.commit(); conn.close()
    return f"✅ {item['emoji']} *{item['name']}* خریداری شد!\n💰 هزینه: {item['price']:,}\n📈 +{ev} {ef}"

# ═══════════════════════════════════════════════════════
#  پاداش روزانه
# ═══════════════════════════════════════════════════════

def cmd_daily(uid):
    conn = get_conn()
    p = conn.execute("SELECT * FROM players WHERE user_id=?", (str(uid),)).fetchone()
    if not p or not p["country_id"]:
        conn.close(); return "❌ اول کشور انتخاب کن: /country"
    today = str(date.today())
    if p["last_daily"] == today:
        conn.close(); return "⏰ امروز پاداش گرفتی!\nفردا دوباره بیا 😊"
    cfg = conn.execute("SELECT * FROM daily_config ORDER BY id DESC LIMIT 1").fetchone()
    conn.execute("UPDATE players SET last_daily=? WHERE user_id=?", (today, str(uid)))
    c_id = p["country_id"]
    conn.execute("""UPDATE countries SET
        money=money+?, oil=oil+?,
        satisfaction=MIN(100,satisfaction+?)
        WHERE id=?""", (cfg["money_reward"], cfg["oil_reward"], cfg["satisfaction_reward"], c_id))
    conn.commit(); conn.close()
    return (f"🎁 *پاداش روزانه دریافت شد!*\n"
            f"💰 +{cfg['money_reward']:,}\n"
            f"🛢 +{cfg['oil_reward']:,}\n"
            f"😊 +{cfg['satisfaction_reward']}%\n\n"
            f"فردا دوباره بیا! 👋")

# ═══════════════════════════════════════════════════════
#  قوانین و راهنما
# ═══════════════════════════════════════════════════════

RULES = """📜 *قوانین بازی جنگ جهانی*
━━━━━━━━━━━━━━━

1️⃣ هر کاربر فقط یه کشور می‌تونه انتخاب کنه
2️⃣ منابع: پول 💰 نفت 🛢 رضایت 😊
3️⃣ با پول می‌تونی ارتش و ساختمان بخری
4️⃣ هر روز یه بار پاداش روزانه می‌تونی بگیری
5️⃣ فروشگاه قاره‌ها آیتم‌های ویژه داره
6️⃣ رضایت بالاتر = عملکرد بهتر
7️⃣ احترام رو رعایت کنید
8️⃣ تقلب = اخراج از بازی"""

HELP = """❓ *راهنمای ربات جنگ جهانی*
━━━━━━━━━━━━━━━

/profile - پروفایل و وضعیت کشورت
/country - انتخاب کشور
/economy - وضعیت اقتصادی
/army - ارتش و خرید نیرو
/buildings - ساختمان‌ها
/shop - فروشگاه قاره‌ها
/daily - پاداش روزانه
/rules - قوانین کامل
/help - این راهنما"""

# ═══════════════════════════════════════════════════════
#  اقتصاد ادمین
# ═══════════════════════════════════════════════════════

def admin_add_all(money, oil, satisfaction, by):
    conn = get_conn()
    conn.execute("""UPDATE countries SET
        money=money+?, oil=oil+?,
        satisfaction=MAX(0,MIN(100,satisfaction+?))
        WHERE is_active=1""", (money, oil, satisfaction))
    conn.execute("INSERT INTO logs (action,performed_by,details) VALUES ('add_all',?,?)",
                 (str(by), f"m={money},o={oil},s={satisfaction}"))
    conn.commit(); conn.close()
    return f"✅ به همه کشورها اضافه شد:\n💰{money:+,} | 🛢{oil:+,} | 😊{satisfaction:+d}"

def admin_set_daily(money, oil, sat, by):
    conn = get_conn()
    conn.execute("INSERT INTO daily_config (money_reward,oil_reward,satisfaction_reward) VALUES (?,?,?)",
                 (money, oil, sat))
    conn.commit(); conn.close()
    return f"✅ پاداش روزانه تنظیم شد:\n💰{money:,} | 🛢{oil:,} | 😊{sat}"

# ─── انواع ارتش ─────────────────────────────────────────
def add_army_type(name, emoji, price, attack, defense, by):
    conn = get_conn()
    try:
        conn.execute("INSERT INTO army_types (name,emoji,price,attack,defense) VALUES (?,?,?,?,?)",
                     (name, emoji, price, attack, defense))
        conn.commit()
        return f"✅ نوع ارتش «{emoji} {name}» اضافه شد."
    except:
        return "❌ این نوع قبلاً وجود داره."
    finally:
        conn.close()

def del_army_type(tid, by):
    conn = get_conn()
    conn.execute("DELETE FROM army_types WHERE id=?", (tid,))
    conn.commit(); conn.close()
    return "✅ نوع ارتش حذف شد."

# ─── انواع ساختمان ───────────────────────────────────────
def add_building_type(name, emoji, price, effect_type, effect_value, desc, by):
    conn = get_conn()
    try:
        conn.execute("INSERT INTO building_types (name,emoji,price,effect_type,effect_value,description) VALUES (?,?,?,?,?,?)",
                     (name, emoji, price, effect_type, effect_value, desc))
        conn.commit()
        return f"✅ ساختمان «{emoji} {name}» اضافه شد."
    except:
        return "❌ این ساختمان قبلاً وجود داره."
    finally:
        conn.close()

# ─── آیتم فروشگاه ───────────────────────────────────────
def add_shop_item(name, emoji, continent, price, effect_type, effect_value, desc, by):
    conn = get_conn()
    try:
        conn.execute("INSERT INTO shop_items (name,emoji,continent,price,effect_type,effect_value,description) VALUES (?,?,?,?,?,?,?)",
                     (name, emoji, continent, price, effect_type, effect_value, desc))
        conn.commit()
        return f"✅ آیتم «{emoji} {name}» به فروشگاه اضافه شد."
    except:
        return "❌ این آیتم قبلاً وجود داره."
    finally:
        conn.close()

# ═══════════════════════════════════════════════════════
#  بکاپ
# ═══════════════════════════════════════════════════════

def create_backup(by):
    conn = get_conn()
    data = json.dumps({
        "countries": [dict(r) for r in conn.execute("SELECT * FROM countries").fetchall()],
        "army": [dict(r) for r in conn.execute("SELECT * FROM army").fetchall()],
        "buildings": [dict(r) for r in conn.execute("SELECT * FROM buildings").fetchall()],
    }, ensure_ascii=False)
    cur = conn.execute("INSERT INTO backups (created_by,data) VALUES (?,?)", (str(by), data))
    bid = cur.lastrowid
    conn.commit(); conn.close()
    return f"✅ بکاپ ذخیره شد. ID: {bid}"

def list_backups():
    conn = get_conn()
    rows = conn.execute("SELECT id,backup_time,created_by FROM backups ORDER BY id DESC LIMIT 15").fetchall()
    conn.close()
    if not rows: return "❌ بکاپی نیست."
    t = "💾 *بکاپ‌ها:*\n\n"
    for b in rows: t += f"[{b['id']}] {b['backup_time']}\n"
    return t

def do_rollback(bid, by):
    conn = get_conn()
    row = conn.execute("SELECT * FROM backups WHERE id=?", (bid,)).fetchone()
    if not row: conn.close(); return "❌ بکاپ پیدا نشد."
    snap = json.loads(row["data"])
    # بکاپ فعلی
    cur_data = json.dumps({
        "countries": [dict(r) for r in conn.execute("SELECT * FROM countries").fetchall()],
        "army": [dict(r) for r in conn.execute("SELECT * FROM army").fetchall()],
        "buildings": [dict(r) for r in conn.execute("SELECT * FROM buildings").fetchall()],
    }, ensure_ascii=False)
    conn.execute("INSERT INTO backups (created_by,data) VALUES (?,?)", ("auto_before_rollback", cur_data))
    # بازگردانی
    for table in ("countries","army","buildings"):
        conn.execute(f"DELETE FROM {table}")
        for row2 in snap[table]:
            cols=",".join(row2.keys()); ph=",".join("?"*len(row2))
            conn.execute(f"INSERT INTO {table} ({cols}) VALUES ({ph})", list(row2.values()))
    conn.commit(); conn.close()
    return f"✅ برگشت به بکاپ [{bid}] انجام شد."

import requests
import time
import sqlite3

from config import BOT_TOKEN, OWNER_ID
from database import setup_db, get_conn
from api import send, get_updates
from game import *

# ─── راه‌اندازی ──────────────────────────────────────────
setup_db()
conn = get_conn()
if not conn.execute("SELECT id FROM admins WHERE is_owner=1").fetchone():
    conn.execute("INSERT OR IGNORE INTO admins (user_id,name,is_owner) VALUES (?,?,1)",
                 (str(OWNER_ID), "Owner"))
    conn.commit()
    print(f"✅ اونر ثبت شد: {OWNER_ID}")
conn.close()

# ═══════════════════════════════════════════════════════
#  پردازش پیام
# ═══════════════════════════════════════════════════════

def handle(msg):
    chat_id = str(msg.get("chat", {}).get("id") or msg.get("from_id", ""))
    text = (msg.get("text") or "").strip()
    user_id = str(msg.get("from_id") or msg.get("author_object_id", ""))
    username = msg.get("from", {}).get("username") or msg.get("from", {}).get("first_name") or user_id

    if not text or not chat_id:
        return

    parts = text.split()
    cmd = parts[0].lower().split("@")[0]

    # ─── دستورات عمومی ──────────────────────────────────

    if cmd == "/start":
        send(chat_id, """🌍 *به ربات جنگ جهانی خوش آمدید!*

دستورات اصلی:
/profile - پروفایل کشور
/country - انتخاب کشور
/economy - اقتصاد
/army - ارتش
/buildings - ساختمان‌ها
/shop - فروشگاه قاره‌ها
/daily - پاداش روزانه
/rules - قوانین کامل
/help - راهنما""")

    elif cmd == "/help":
        send(chat_id, HELP)

    elif cmd == "/rules":
        send(chat_id, RULES)

    elif cmd == "/profile":
        send(chat_id, cmd_profile(user_id))

    elif cmd == "/country":
        if len(parts) == 1:
            send(chat_id, get_countries_list())
        else:
            try:
                cid = int(parts[1])
            except:
                send(chat_id, "❌ ID باید عدد باشه."); return
            result = select_country(user_id, cid, username)
            if isinstance(result, dict):
                send(chat_id, result["msg"])
                if result["is_full"]:
                    # اطلاع به ادمین‌ها
                    conn2 = get_conn()
                    admins = conn2.execute("SELECT user_id FROM admins").fetchall()
                    conn2.close()
                    for a in admins:
                        send(a["user_id"], f"🔔 کشور «{result['country_name']}» پر شد!")
            else:
                send(chat_id, result)

    elif cmd == "/economy":
        send(chat_id, cmd_economy(user_id))

    elif cmd == "/army":
        send(chat_id, cmd_army(user_id))

    elif cmd == "/buy_army":
        if len(parts) < 3:
            send(chat_id, "⚠️ /buy_army [ID_نوع] [تعداد]"); return
        try:
            send(chat_id, buy_army(user_id, int(parts[1]), int(parts[2])))
        except:
            send(chat_id, "❌ فرمت اشتباه. مثال: /buy_army 1 10")

    elif cmd == "/buildings":
        send(chat_id, cmd_buildings(user_id))

    elif cmd == "/buy_building":
        if len(parts) < 3:
            send(chat_id, "⚠️ /buy_building [ID_نوع] [تعداد]"); return
        try:
            send(chat_id, buy_building(user_id, int(parts[1]), int(parts[2])))
        except:
            send(chat_id, "❌ فرمت اشتباه. مثال: /buy_building 1 2")

    elif cmd == "/shop":
        send(chat_id, cmd_shop(user_id))

    elif cmd == "/buy_item":
        if len(parts) < 2:
            send(chat_id, "⚠️ /buy_item [ID]"); return
        try:
            send(chat_id, buy_item(user_id, int(parts[1])))
        except:
            send(chat_id, "❌ فرمت اشتباه.")

    elif cmd == "/daily":
        send(chat_id, cmd_daily(user_id))

    # ─── دستورات ادمین ──────────────────────────────────

    elif cmd == "/admin":
        if not is_admin(user_id):
            send(chat_id, "❌ دسترسی ندارید."); return
        send(chat_id, """👮 *پنل ادمین:*

🏳 کشور:
/add\_country [نام] [پرچم] [قاره]
/del\_country [ID]
/edit\_country [ID] [فیلد] [مقدار]

⚔️ ارتش:
/add\_army\_type [نام] [emoji] [قیمت] [حمله] [دفاع]
/del\_army\_type [ID]

🏛 ساختمان:
/add\_building [نام] [emoji] [قیمت] [نوع_اثر] [مقدار_اثر] [توضیح]

🛍 فروشگاه:
/add\_item [نام] [emoji] [قاره] [قیمت] [نوع_اثر] [مقدار] [توضیح]

💰 اقتصاد:
/add\_all [پول] [نفت] [رضایت]
/set\_daily [پول] [نفت] [رضایت]

💾 بکاپ:
/backup
/backups
/rollback [ID]

👑 اونر:
/add\_admin [user\_id] [نام]
/del\_admin [user\_id]
/admins""")

    elif cmd == "/add_country":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        # /add_country ایران 🇮🇷 آسیا
        if len(parts) < 4:
            send(chat_id, "⚠️ /add_country [نام] [پرچم] [قاره]\nمثال: /add_country ایران 🇮🇷 آسیا"); return
        send(chat_id, add_country(parts[1], parts[2], " ".join(parts[3:]), user_id))

    elif cmd == "/del_country":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        if len(parts) < 2: send(chat_id, "⚠️ /del_country [ID]"); return
        send(chat_id, del_country(int(parts[1]), user_id))

    elif cmd == "/edit_country":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        if len(parts) < 4: send(chat_id, "⚠️ /edit_country [ID] [فیلد] [مقدار]"); return
        numeric = {"money","oil","satisfaction","max_players"}
        val = int(parts[3]) if parts[2] in numeric else parts[3]
        send(chat_id, edit_country(int(parts[1]), parts[2], val, user_id))

    elif cmd == "/add_army_type":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        if len(parts) < 6:
            send(chat_id, "⚠️ /add_army_type [نام] [emoji] [قیمت] [حمله] [دفاع]\nمثال: /add_army_type تانک 🚀 1000 20 10"); return
        send(chat_id, add_army_type(parts[1], parts[2], int(parts[3]), int(parts[4]), int(parts[5]), user_id))

    elif cmd == "/del_army_type":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        if len(parts) < 2: send(chat_id, "⚠️ /del_army_type [ID]"); return
        send(chat_id, del_army_type(int(parts[1]), user_id))

    elif cmd == "/add_building":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        if len(parts) < 7:
            send(chat_id, "⚠️ /add_building [نام] [emoji] [قیمت] [نوع_اثر] [مقدار] [توضیح]\nمثال: /add_building کارخانه 🏭 2000 money 500 تولید_پول"); return
        send(chat_id, add_building_type(parts[1], parts[2], int(parts[3]), parts[4], int(parts[5]), " ".join(parts[6:]), user_id))

    elif cmd == "/add_item":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        if len(parts) < 8:
            send(chat_id, "⚠️ /add_item [نام] [emoji] [قاره] [قیمت] [نوع_اثر] [مقدار] [توضیح]\nمثال: /add_item نفت_ویژه ⚡ آسیا 3000 oil 1000 نفت_اضافه"); return
        send(chat_id, add_shop_item(parts[1], parts[2], parts[3], int(parts[4]), parts[5], int(parts[6]), " ".join(parts[7:]), user_id))

    elif cmd == "/add_all":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        if len(parts) < 4: send(chat_id, "⚠️ /add_all [پول] [نفت] [رضایت]\nمثال: /add_all 500 200 5"); return
        send(chat_id, admin_add_all(int(parts[1]), int(parts[2]), int(parts[3]), user_id))

    elif cmd == "/set_daily":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        if len(parts) < 4: send(chat_id, "⚠️ /set_daily [پول] [نفت] [رضایت]"); return
        send(chat_id, admin_set_daily(int(parts[1]), int(parts[2]), int(parts[3]), user_id))

    elif cmd == "/backup":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        send(chat_id, create_backup(user_id))

    elif cmd == "/backups":
        if not is_admin(user_id): send(chat_id, "❌ دسترسی ندارید."); return
        send(chat_id, list_backups())

    elif cmd == "/rollback":
        if not is_owner(user_id): send(chat_id, "❌ فقط اونر."); return
        if len(parts) < 2: send(chat_id, "⚠️ /rollback [ID]"); return
        send(chat_id, do_rollback(int(parts[1]), user_id))

    elif cmd == "/add_admin":
        if not is_owner(user_id): send(chat_id, "❌ فقط اونر."); return
        if len(parts) < 3: send(chat_id, "⚠️ /add_admin [user_id] [نام]"); return
        send(chat_id, add_admin(parts[1], " ".join(parts[2:]), user_id))

    elif cmd == "/del_admin":
        if not is_owner(user_id): send(chat_id, "❌ فقط اونر."); return
        if len(parts) < 2: send(chat_id, "⚠️ /del_admin [user_id]"); return
        send(chat_id, del_admin(parts[1], user_id))

    elif cmd == "/admins":
        if not is_owner(user_id): send(chat_id, "❌ فقط اونر."); return
        send(chat_id, list_admins())

# ═══════════════════════════════════════════════════════
#  حلقه اصلی
# ═══════════════════════════════════════════════════════

def main():
    print("🚀 ربات جنگ جهانی شروع به کار کرد...")
    offset = None
    while True:
        try:
            updates = get_updates(offset)
            for update in updates:
                offset = update.get("update_id", 0) + 1
                msg = update.get("message") or update.get("edited_message")
                if msg:
                    try:
                        handle(msg)
                    except Exception as e:
                        print(f"⚠️ خطا در handle: {e}")
        except Exception as e:
            print(f"⚠️ خطا: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()

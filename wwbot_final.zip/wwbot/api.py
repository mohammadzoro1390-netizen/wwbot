import requests
from config import BOT_TOKEN, API_URL

def send(chat_id, text):
    url = f"{API_URL}/{BOT_TOKEN}/sendMessage"
    try:
        requests.post(url, json={"chat_id": chat_id, "text": text, "parse_mode": "Markdown"}, timeout=10)
    except:
        pass

def get_updates(offset=None):
    url = f"{API_URL}/{BOT_TOKEN}/getUpdates"
    data = {"timeout": 30}
    if offset:
        data["offset"] = offset
    try:
        r = requests.post(url, json=data, timeout=35)
        return r.json().get("result", [])
    except:
        return []

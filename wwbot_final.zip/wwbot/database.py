import sqlite3
from config import DB_PATH

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def setup_db():
    conn = get_conn()
    c = conn.cursor()

    # ادمین‌ها
    c.execute('''CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE NOT NULL,
        name TEXT,
        is_owner INTEGER DEFAULT 0
    )''')

    # کشورها (ادمین تعریف می‌کنه)
    c.execute('''CREATE TABLE IF NOT EXISTS countries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        flag TEXT DEFAULT "🏳",
        continent TEXT DEFAULT "",
        money INTEGER DEFAULT 5000,
        oil INTEGER DEFAULT 1000,
        satisfaction INTEGER DEFAULT 70,
        max_players INTEGER DEFAULT 10,
        current_players INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1
    )''')

    # بازیکنان
    c.execute('''CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE NOT NULL,
        username TEXT DEFAULT "",
        country_id INTEGER DEFAULT NULL,
        last_daily TEXT DEFAULT NULL
    )''')

    # ارتش (ادمین نوع تعریف می‌کنه)
    c.execute('''CREATE TABLE IF NOT EXISTS army_types (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        emoji TEXT DEFAULT "⚔️",
        price INTEGER DEFAULT 1000,
        attack INTEGER DEFAULT 10,
        defense INTEGER DEFAULT 5
    )''')

    # ارتش کشورها
    c.execute('''CREATE TABLE IF NOT EXISTS army (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        country_id INTEGER NOT NULL,
        army_type_id INTEGER NOT NULL,
        amount INTEGER DEFAULT 0,
        UNIQUE(country_id, army_type_id)
    )''')

    # ساختمان‌ها (ادمین تعریف می‌کنه)
    c.execute('''CREATE TABLE IF NOT EXISTS building_types (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        emoji TEXT DEFAULT "🏛",
        price INTEGER DEFAULT 2000,
        effect_type TEXT DEFAULT "money",
        effect_value INTEGER DEFAULT 100,
        description TEXT DEFAULT ""
    )''')

    # ساختمان‌های کشورها
    c.execute('''CREATE TABLE IF NOT EXISTS buildings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        country_id INTEGER NOT NULL,
        building_type_id INTEGER NOT NULL,
        amount INTEGER DEFAULT 0,
        UNIQUE(country_id, building_type_id)
    )''')

    # فروشگاه قاره‌ها (آیتم‌های ویژه)
    c.execute('''CREATE TABLE IF NOT EXISTS shop_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        emoji TEXT DEFAULT "🛍",
        continent TEXT DEFAULT "همه",
        price INTEGER DEFAULT 5000,
        effect_type TEXT DEFAULT "money",
        effect_value INTEGER DEFAULT 500,
        description TEXT DEFAULT ""
    )''')

    # تنظیمات پاداش روزانه
    c.execute('''CREATE TABLE IF NOT EXISTS daily_config (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        money_reward INTEGER DEFAULT 500,
        oil_reward INTEGER DEFAULT 200,
        satisfaction_reward INTEGER DEFAULT 5
    )''')

    # بکاپ
    c.execute('''CREATE TABLE IF NOT EXISTS backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        backup_time TEXT DEFAULT CURRENT_TIMESTAMP,
        created_by TEXT,
        data TEXT NOT NULL
    )''')

    # لاگ
    c.execute('''CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT,
        performed_by TEXT,
        details TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    # پیش‌فرض daily
    if conn.execute("SELECT COUNT(*) FROM daily_config").fetchone()[0] == 0:
        conn.execute("INSERT INTO daily_config (money_reward,oil_reward,satisfaction_reward) VALUES (500,200,5)")

    conn.commit()
    conn.close()
    print("✅ دیتابیس آماده شد.")
